Assignment 1 10/10/2017


=======================
STUDENT INFORMATIONS:
=======================
NAME: Yizhang Cao     STUDENT ID: 101038053
NAME: Elaine Deng     STUDENT ID: 101045610


======================
PROGRAM INFORMATION:
======================
This program contains 12 files
App.cpp
App.h
main.cpp
UI.cpp
UI.h
str_util.cpp
str_util.h
Makefile
README.txt
help.txt
InsertDataScript.txt
CommandTestScript.txt


===================
Extraction Command:
===================
tar -xvf mytunes_final.tar


=====================
g++ Compiler Command:
=====================
make -f Makefile


============================
Running the executable file:
============================
./mytunes


===========================
Scripts to run for testing:
===========================
.read InsertDataScript.txt

.read CommandTestScript.txt

"InsertDataScript.txt" is used to enter all the data from the beatles.db database.

“CommandTestScript.txt" is used to test whether the functional requirements have been met.