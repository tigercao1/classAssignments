#include <string>
#include <iostream>
#include <fstream>

#include "App.h"

using namespace std;

int main(){
  App myApplication;
	myApplication.run();
  return 0;
}
